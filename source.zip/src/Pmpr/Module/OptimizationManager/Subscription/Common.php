<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1d0de2de0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting; use Pmpr\Module\OptimizationManager\Container; abstract class Common extends Container { public function kmuweyayaqoeqiyw() : ?Setting { return Setting::symcgieuakksimmu(); } }
