<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6b052b7ef3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Module\OptimizationManager\Container; abstract class Common extends Container { public function ikcgmcycisiccyuc() { $this->settingObj = Setting::symcgieuakksimmu(); } }
