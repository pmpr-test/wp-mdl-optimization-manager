<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d62ec4d0b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Module\OptimizationManager\Container; abstract class Common extends Container { public function ikcgmcycisiccyuc() { $this->settingObj = Setting::symcgieuakksimmu(); } }
