<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae90cf005b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Traits; use Pmpr\Module\OptimizationManager\Subscription\Engine; trait EngineTrait { public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
