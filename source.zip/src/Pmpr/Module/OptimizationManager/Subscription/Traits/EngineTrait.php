<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77bc3b3dd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Traits; use Pmpr\Module\OptimizationManager\Subscription\Engine; trait EngineTrait { public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
