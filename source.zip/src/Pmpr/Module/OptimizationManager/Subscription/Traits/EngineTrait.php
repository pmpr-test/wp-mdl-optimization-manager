<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d82ad66b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Traits; use Pmpr\Module\OptimizationManager\Subscription\Engine; trait EngineTrait { public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
