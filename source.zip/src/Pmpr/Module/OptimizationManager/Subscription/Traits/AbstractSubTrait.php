<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d867899bbc             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Traits; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\DomainManager\Model\Domain; trait AbstractSubTrait { public function yseaccyokaeameou($qamwkmomamooqqic) { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->ywggokoaagwwqyak([Constants::squoamkioomemiyi => Constants::emkkgysokckswycs, Constants::emkkgysokckswycs => Domain::symcgieuakksimmu(), Constants::ckmqoekmugkggeym => $qamwkmomamooqqic]); } public function ogkiouuqqmaagscs($qamwkmomamooqqic) : string { $pkyyagewkiyckmwy = ''; if ($qamwkmomamooqqic) { $pkyyagewkiyckmwy = Domain::symcgieuakksimmu()->uikgwcuascgeissw($qamwkmomamooqqic); } return $pkyyagewkiyckmwy; } }
