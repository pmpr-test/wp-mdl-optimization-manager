<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc54f1102a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Woocommerce; use Pmpr\Common\Subscription\Woocommerce\Order as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Order extends BaseClass { use EngineTrait; }
