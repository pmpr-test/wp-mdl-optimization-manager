<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d867899bbc             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; class Manager extends Common { }
