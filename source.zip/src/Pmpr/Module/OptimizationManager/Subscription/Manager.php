<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46c91cced             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; class Manager extends Common { }
