<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6affe3ed94             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; class Manager extends Common { }
