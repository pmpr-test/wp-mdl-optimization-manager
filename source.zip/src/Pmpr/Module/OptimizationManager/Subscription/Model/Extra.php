<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6b052b7ef3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Subscription\Model\Extra as BaseClass; use Pmpr\Module\DomainManager\Model\Domain; use Pmpr\Module\OptimizationManager\Subscription\Traits\AbstractSubTrait; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Extra extends BaseClass { use AbstractSubTrait, EngineTrait; public function aoqwywcqmoqaukkq() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(Constants::kuqwimiimiqsimgo)->ugquamoakekwyiqg(Domain::class)->mkmssscwmeekwgqo()); parent::aoqwywcqmoqaukkq(); } public function kamyqikiiuwqiiuw($qgoqiacsiccwoawi, $eqgoocgaqwqcimie, &$mksyucucyswaukig = null) { switch ($qgoqiacsiccwoawi) { case Constants::ciyoccqkiamemcmm: $eqgoocgaqwqcimie = sprintf(__("\45\163\40\143\157\x69\x6e\x73", PR__MDL__OPTIMIZATION_MANAGER), $this->caokeucsksukesyo()->gagsyqagguwwauac()->eusockqasqqmoess($eqgoocgaqwqcimie)); goto wakmayaoqoskekqy; } qmuwoecuacmkwgem: wakmayaoqoskekqy: return parent::kamyqikiiuwqiiuw($qgoqiacsiccwoawi, $eqgoocgaqwqcimie, $mksyucucyswaukig); } }
