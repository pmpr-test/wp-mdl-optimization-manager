<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d8616a1eda             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Subscription\Model\Extra as BaseClass; use Pmpr\Module\DomainManager\Model\Domain; use Pmpr\Module\OptimizationManager\Subscription\Traits\AbstractSubTrait; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Extra extends BaseClass { use AbstractSubTrait, EngineTrait; public function aoqwywcqmoqaukkq() { $this->yyoqecggyacaseko()->mkksewyosgeumwsa($this->caokeucsksukesyo()->wmkogisswkckmeua()->mccagaqeagiikkec(Constants::kuqwimiimiqsimgo)->ugquamoakekwyiqg(Domain::class)->mkmssscwmeekwgqo()); parent::aoqwywcqmoqaukkq(); } public function iukqkygkscmaiaay($eqgoocgaqwqcimie) { return sprintf(__("\45\x73\x20\143\x6f\151\156\x73", PR__MDL__OPTIMIZATION_MANAGER), $this->caokeucsksukesyo()->gagsyqagguwwauac()->eusockqasqqmoess($eqgoocgaqwqcimie)); } }
