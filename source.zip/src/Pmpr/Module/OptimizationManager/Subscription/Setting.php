<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d8616a1eda             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\x5f\x73\x75\x62"; $this->hasLicense = false; $this->title = __("\123\x75\x62\163\143\x72\151\160\164\x69\x6f\156\40\x53\145\x74\164\x69\x6e\147", PR__MDL__OPTIMIZATION_MANAGER); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\117\x70\164\151\x6d\x69\172\141\164\x69\x6f\156\x20\115\x61\156\141\x67\145\x72\40\x53\165\142\163\x63\x72\x69\160\164\151\157\x6e\40\x53\145\x74\164\x69\x6e\x67", PR__MDL__OPTIMIZATION_MANAGER)); } }
