<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d893887a06             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\x5f\163\x75\142"; $this->hasLicense = false; $this->title = __("\123\165\x62\163\x63\162\151\x70\164\151\x6f\156\x20\123\145\x74\164\151\x6e\147", PR__MDL__OPTIMIZATION_MANAGER); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\x4f\160\164\x69\155\151\172\141\164\151\x6f\x6e\x20\x4d\141\156\141\x67\x65\162\x20\x53\x75\142\163\143\x72\151\160\164\x69\157\156\40\123\x65\x74\x74\x69\x6e\147", PR__MDL__OPTIMIZATION_MANAGER)); } }
