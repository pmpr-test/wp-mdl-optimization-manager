<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc54f1102a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\x5f\163\165\x62"; $this->hasLicense = false; $this->title = __("\x53\x75\142\163\x63\162\x69\x70\x74\151\157\x6e\40\123\x65\x74\164\x69\x6e\x67", PR__MDL__OPTIMIZATION_MANAGER); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\117\160\x74\151\x6d\x69\x7a\141\164\151\157\156\x20\115\x61\x6e\x61\147\x65\x72\40\x53\165\x62\163\143\x72\x69\160\x74\151\x6f\x6e\x20\x53\x65\x74\164\x69\x6e\147", PR__MDL__OPTIMIZATION_MANAGER)); } }
