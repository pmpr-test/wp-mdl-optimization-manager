<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b252eb73             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\x5f\x73\x75\x62"; $this->hasLicense = false; $this->title = __("\x53\x75\x62\163\143\x72\151\160\164\x69\157\x6e\x20\123\145\164\164\x69\156\x67", PR__MDL__OPTIMIZATION_MANAGER); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\117\160\x74\151\x6d\151\x7a\141\164\151\157\x6e\x20\x4d\x61\156\x61\147\x65\x72\40\123\165\x62\163\x63\162\x69\x70\164\x69\x6f\156\x20\x53\145\164\164\151\x6e\147", PR__MDL__OPTIMIZATION_MANAGER)); } }
