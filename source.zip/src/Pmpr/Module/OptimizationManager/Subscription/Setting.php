<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d867899bbc             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\x5f\x73\x75\x62"; $this->hasLicense = false; $this->title = __("\123\165\x62\163\x63\162\x69\x70\x74\151\157\156\x20\123\145\x74\164\151\156\x67", PR__MDL__OPTIMIZATION_MANAGER); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\x4f\160\x74\151\155\151\x7a\x61\164\x69\x6f\156\40\115\141\x6e\x61\x67\x65\x72\x20\123\165\x62\163\x63\162\x69\x70\x74\151\x6f\x6e\x20\x53\145\x74\164\x69\156\147", PR__MDL__OPTIMIZATION_MANAGER)); } }
