<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d82ad66b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\x5f\163\165\142"; $this->hasLicense = false; $this->title = __("\x53\165\x62\163\143\162\151\160\164\x69\x6f\x6e\x20\123\x65\x74\x74\x69\156\x67", PR__MDL__OPTIMIZATION_MANAGER); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\117\x70\164\x69\x6d\x69\172\x61\x74\x69\157\x6e\x20\x4d\x61\x6e\x61\147\x65\162\40\123\x75\x62\163\x63\162\x69\160\164\151\157\x6e\40\123\x65\x74\x74\151\156\x67", PR__MDL__OPTIMIZATION_MANAGER)); } }
