<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77bc3b3dd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\137\x73\x75\142"; $this->hasLicense = false; $this->title = __("\123\x75\x62\x73\x63\162\x69\x70\x74\151\x6f\x6e\40\x53\x65\164\164\x69\156\x67", PR__MDL__OPTIMIZATION_MANAGER); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\117\160\164\151\155\151\x7a\x61\164\x69\157\x6e\x20\115\x61\x6e\x61\x67\145\x72\40\123\165\142\163\x63\x72\151\x70\164\151\157\156\40\x53\x65\164\x74\151\x6e\147", PR__MDL__OPTIMIZATION_MANAGER)); } }
