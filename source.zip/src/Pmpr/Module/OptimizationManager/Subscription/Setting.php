<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6714e1dd0392d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Subscription\Setting as BaseClass; use Pmpr\Module\OptimizationManager\Subscription\Traits\EngineTrait; class Setting extends BaseClass { use EngineTrait; public function qiccuiwooiquycsg() { parent::qiccuiwooiquycsg(); $this->id .= "\x5f\163\165\142"; $this->hasLicense = false; $this->title = __("\123\165\x62\x73\x63\x72\151\x70\x74\x69\x6f\156\40\x53\145\x74\x74\151\x6e\x67", PR__MDL__OPTIMIZATION_MANAGER); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\117\x70\x74\x69\x6d\151\172\x61\164\x69\x6f\x6e\x20\x4d\x61\156\141\147\x65\162\x20\x53\165\142\x73\143\162\x69\x70\164\x69\x6f\156\x20\123\145\164\164\151\156\x67", PR__MDL__OPTIMIZATION_MANAGER)); } }
