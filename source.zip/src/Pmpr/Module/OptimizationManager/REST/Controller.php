<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d62ec4d0b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\REST; use Pmpr\Common\Foundation\REST\RESTController; class Controller extends RESTController { public function ikcgmcycisiccyuc() { $this->rest_base = "\157\160\x74\151\155\x69\172\141\x74\x69\157\156\x2d\155\141\x6e\x61\147\x65\162"; } }
