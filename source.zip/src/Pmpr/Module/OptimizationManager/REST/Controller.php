<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6b052b7ef3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\REST; use Pmpr\Common\Foundation\REST\RESTController; class Controller extends RESTController { public function ikcgmcycisiccyuc() { $this->rest_base = "\157\x70\x74\151\x6d\151\172\141\164\151\x6f\x6e\x2d\x6d\141\156\141\x67\x65\x72"; } }
