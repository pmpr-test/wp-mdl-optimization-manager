<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d62ec4d0b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Frontend; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\OptimizationManager\Setting; class Request extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\x77\x70\55\163\160\145\145\x64\55\162\x65\x71\x75\145\x73\x74")->sqemekeuykmooums()->gswweykyogmsyawy(__("\117\x70\164\x69\x6d\x69\172\x61\164\x69\x6f\x6e\x20\115\x6f\x64\165\x6c\145\x20\x52\145\x71\165\145\x73\x74\40\x50\141\x67\145", PR__MDL__OPTIMIZATION_MANAGER))->wmsaakuicamguoam((int) Setting::symcgieuakksimmu()->giiuwsmyumqwwiyq(Setting::eiguikqsqiemumcm, 0)); } public function rsysgcucogueguuk() : array { return [Constants::qescuiwgsyuikume => $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->qcgakseyaikigqco($this->iooowgsqoyqseyuu()), Constants::ccggwaweegsyygga => RequestMultistep::symcgieuakksimmu()->yqqscekqmcgwkiao(), Constants::eqkeooqcsscoggia => $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->masoymaamekuykso($this->iooowgsqoyqseyuu(), true)]; } }
