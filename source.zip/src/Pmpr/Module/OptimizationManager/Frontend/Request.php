<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b252eb73             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Frontend; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\OptimizationManager\Setting; class Request extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\x77\x70\x2d\163\160\145\145\144\55\162\145\x71\165\145\x73\164")->sqemekeuykmooums()->gswweykyogmsyawy(__("\117\x70\164\151\155\x69\172\x61\164\151\x6f\156\x20\115\x6f\x64\x75\x6c\145\x20\x52\x65\x71\x75\145\x73\164\40\x50\x61\147\x65", PR__MDL__OPTIMIZATION_MANAGER))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::eiguikqsqiemumcm, 0)); } public function rsysgcucogueguuk() : array { return [Constants::qescuiwgsyuikume => $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->qcgakseyaikigqco($this->iooowgsqoyqseyuu()), Constants::ccggwaweegsyygga => RequestMultistep::symcgieuakksimmu()->yqqscekqmcgwkiao(), Constants::eqkeooqcsscoggia => $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->masoymaamekuykso($this->iooowgsqoyqseyuu(), true)]; } }
