<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6714e1dd0392d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Frontend; use Pmpr\Common\Foundation\Frontend\Page; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\OptimizationManager\Setting; class Request extends Page { public function qiccuiwooiquycsg() { $this->wegcaymyqqoyewmw("\167\160\55\163\160\145\x65\x64\55\x72\x65\161\165\145\163\x74")->sqemekeuykmooums()->gswweykyogmsyawy(__("\x4f\x70\164\151\155\x69\172\141\x74\151\x6f\156\x20\115\157\x64\165\x6c\145\40\122\145\161\165\145\x73\x74\40\x50\141\x67\145", PR__MDL__OPTIMIZATION_MANAGER))->wmsaakuicamguoam($this->weysguygiseoukqw(Setting::eiguikqsqiemumcm, 0)); } public function rsysgcucogueguuk() : array { return [Constants::qescuiwgsyuikume => $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->qcgakseyaikigqco($this->iooowgsqoyqseyuu()), Constants::ccggwaweegsyygga => RequestMultistep::symcgieuakksimmu()->yqqscekqmcgwkiao(), Constants::eqkeooqcsscoggia => $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->masoymaamekuykso($this->iooowgsqoyqseyuu(), true)]; } }
