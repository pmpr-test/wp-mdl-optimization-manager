<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6affe3ed94             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\x70\164\151\x6d\x69\172\x61\x74\151\x6f\156\137\143\x75\x73\164\x6f\155\x65\162\x73"; public function __construct() { $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->args = ["\x70\141\x72\145\x6e\x74\x5f\x73\154\x75\147" => $wksoawcgagcgoask, "\x70\141\x67\145\x5f\164\x69\164\154\145" => __("\x43\x75\163\164\x6f\x6d\x65\x72\x73", PR__MDL__OPTIMIZATION_MANAGER), "\155\x65\156\x75\x5f\163\x6c\x75\147" => self::wuowaiyouwecckaw, "\160\157\x73\x69\164\x69\157\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
