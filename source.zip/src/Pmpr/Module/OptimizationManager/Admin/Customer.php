<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6b052b7ef3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\160\x74\151\155\151\x7a\x61\164\151\x6f\156\x5f\x63\x75\x73\x74\x6f\x6d\145\162\x73"; public function __construct() { $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->args = ["\160\x61\x72\145\156\x74\137\163\x6c\165\147" => $wksoawcgagcgoask, "\x70\141\x67\x65\137\164\151\164\x6c\145" => __("\103\x75\x73\x74\157\155\x65\x72\163", PR__MDL__OPTIMIZATION_MANAGER), "\x6d\x65\156\x75\x5f\x73\x6c\x75\x67" => self::wuowaiyouwecckaw, "\x70\157\163\151\x74\151\x6f\156" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
