<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec7a7b695             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\160\x74\x69\155\x69\x7a\x61\164\151\x6f\156\x5f\143\x75\x73\164\x6f\x6d\x65\162\163"; public function __construct() { $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->args = ["\x70\141\162\x65\x6e\164\x5f\x73\154\165\147" => $wksoawcgagcgoask, "\x70\x61\x67\x65\137\x74\x69\x74\154\x65" => __("\103\165\163\164\157\x6d\x65\x72\x73", PR__MDL__OPTIMIZATION_MANAGER), "\x6d\x65\156\x75\x5f\x73\x6c\165\147" => self::wuowaiyouwecckaw, "\x70\x6f\163\151\164\x69\157\156" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
