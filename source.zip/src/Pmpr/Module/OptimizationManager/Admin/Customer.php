<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77020c770             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\157\160\164\x69\x6d\x69\x7a\x61\164\x69\157\x6e\137\x63\165\163\x74\157\x6d\145\x72\x73"; public function __construct() { $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->args = ["\160\x61\162\x65\x6e\164\x5f\163\x6c\165\x67" => $wksoawcgagcgoask, "\x70\x61\x67\x65\137\x74\x69\x74\x6c\x65" => __("\x43\165\163\164\x6f\155\145\x72\163", PR__MDL__OPTIMIZATION_MANAGER), "\155\145\156\165\137\x73\154\x75\x67" => self::wuowaiyouwecckaw, "\x70\157\163\151\x74\x69\x6f\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
