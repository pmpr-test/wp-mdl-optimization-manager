<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77bc3b3dd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\160\164\151\x6d\x69\172\141\x74\x69\157\x6e\137\x63\x75\x73\x74\x6f\x6d\145\162\x73"; public function __construct() { $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->args = ["\x70\141\x72\x65\x6e\164\137\163\x6c\x75\x67" => $wksoawcgagcgoask, "\x70\x61\147\x65\x5f\x74\151\x74\154\x65" => __("\x43\165\x73\x74\157\x6d\x65\162\163", PR__MDL__OPTIMIZATION_MANAGER), "\x6d\145\x6e\x75\x5f\163\x6c\x75\147" => self::wuowaiyouwecckaw, "\x70\x6f\x73\151\164\151\x6f\156" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
