<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d62ec4d0b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\160\x74\x69\155\x69\x7a\141\164\x69\157\156\137\143\x75\163\x74\157\155\145\162\163"; public function __construct() { $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->args = ["\160\x61\x72\145\x6e\x74\x5f\x73\154\165\x67" => $wksoawcgagcgoask, "\160\x61\147\145\137\164\151\164\154\x65" => __("\103\165\x73\x74\x6f\x6d\x65\162\x73", PR__MDL__OPTIMIZATION_MANAGER), "\155\x65\156\x75\x5f\163\154\165\147" => self::wuowaiyouwecckaw, "\x70\157\163\x69\164\151\157\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
