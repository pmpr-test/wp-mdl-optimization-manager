<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7ac614f5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Admin; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\157\160\164\x69\155\151\x7a\141\x74\x69\157\156\137\x63\x75\x73\x74\x6f\x6d\145\162\163"; public function __construct() { $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->args = ["\x70\141\x72\x65\x6e\x74\137\163\x6c\165\x67" => $wksoawcgagcgoask, "\x70\141\x67\x65\x5f\164\x69\x74\154\x65" => __("\103\165\x73\164\x6f\155\x65\x72\x73", PR__MDL__OPTIMIZATION_MANAGER), "\155\x65\x6e\165\x5f\163\154\165\147" => self::wuowaiyouwecckaw, "\160\x6f\163\151\x74\x69\x6f\x6e" => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
