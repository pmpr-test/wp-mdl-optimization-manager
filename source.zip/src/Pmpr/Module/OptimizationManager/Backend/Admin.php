<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             680106308baab             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Backend; use Pmpr\Module\OptimizationManager\Container; class Admin extends Container { public function mameiwsayuyquoeq() { Customer::symcgieuakksimmu(); } }
