<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d82ad66b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Backend; use Pmpr\Module\OptimizationManager\Container; class Admin extends Container { public function mameiwsayuyquoeq() { Customer::symcgieuakksimmu(); } }
