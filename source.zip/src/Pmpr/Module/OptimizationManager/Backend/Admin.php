<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc54f1102a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Backend; use Pmpr\Module\OptimizationManager\Container; class Admin extends Container { public function mameiwsayuyquoeq() { Customer::symcgieuakksimmu(); } }
