<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1d0de2de0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Backend; use Pmpr\Module\OptimizationManager\Container; class Admin extends Container { public function mameiwsayuyquoeq() { Customer::symcgieuakksimmu(); } }
