<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d9805680db             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Backend; use Pmpr\Module\OptimizationManager\Container; class Admin extends Container { public function mameiwsayuyquoeq() { Customer::symcgieuakksimmu(); } }
