<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d82ad66b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\160\164\x69\x6d\x69\172\141\164\151\157\x6e\x5f\143\165\163\164\157\x6d\x65\x72\x73"; public function __construct() { $wksoawcgagcgoask = $this->caokeucsksukesyo()->cqusmgskowmesgcg()->aakmagwggmkoiiyu($this); $this->args = [Constants::qoquaeuooeycomks => $wksoawcgagcgoask, Constants::ysgwugcqguggmigq => __("\x43\165\x73\164\x6f\x6d\145\x72\x73", PR__MDL__OPTIMIZATION_MANAGER), Constants::wuowaiyouwecckaw => self::wuowaiyouwecckaw, Constants::kekcgssiyagioocg => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
