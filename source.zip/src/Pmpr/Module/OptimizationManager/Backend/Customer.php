<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc54f1102a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\OptimizationManager\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Page\Admin\Page; class Customer extends Page { const wuowaiyouwecckaw = "\x6f\x70\x74\x69\155\x69\x7a\141\x74\151\x6f\x6e\137\x63\165\163\x74\x6f\155\x65\x72\x73"; public function __construct() { $wksoawcgagcgoask = $this->caokeucsksukesyo()->cqusmgskowmesgcg()->aakmagwggmkoiiyu($this); $this->args = [Constants::qoquaeuooeycomks => $wksoawcgagcgoask, Constants::ysgwugcqguggmigq => __("\103\x75\x73\164\x6f\155\x65\x72\163", PR__MDL__OPTIMIZATION_MANAGER), Constants::wuowaiyouwecckaw => self::wuowaiyouwecckaw, Constants::kekcgssiyagioocg => 0]; parent::__construct(); } public function suicksywcwiggasc() { $this->listTable = new CustomerList(); $this->waeasakssissiuqg()->prepare_items(); parent::suicksywcwiggasc(); } }
